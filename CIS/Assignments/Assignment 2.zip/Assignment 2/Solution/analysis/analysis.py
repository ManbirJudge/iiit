import sys

import numpy as np
import matplotlib.pyplot as plt

KJ_2_KCAL = 1 / 4.184  # OpenMM writes kJ/mol | NAMD writes kcal/mol

def read_openmm(path):
    res = np.atleast_2d(np.genfromtxt(path, delimiter=',', skip_header=1))

    return res[:, 1], dict(
        PE=res[:, 2] * KJ_2_KCAL,
        KE=res[:, 3] * KJ_2_KCAL,
        E= res[:, 4] * KJ_2_KCAL,
        T= res[:, 5]
    )

def read_namd(path):
    cols, rows, dt_fs = None, [], 2.0
    for line in open(path):
        if line.startswith('Info: TIMESTEP '):
            dt_fs = float(line.split()[2])          # timestep in fs, read from the log
        elif line.startswith('ETITLE:'):
            cols = line.split()[1:]
        elif line.startswith('ENERGY:'):
            rows.append([float(x) for x in line.split()[1:]])
    if not rows:
        sys.exit(f'No ENERGY: lines in {path}. Has NAMD finished (tail -3 {path})?')
    d = np.array(rows); c = {k: i for i, k in enumerate(cols)}
    t = d[:, c['TS']] * dt_fs / 1000                 # ps
    return t, dict(KE=d[:, c['KINETIC']], PE=d[:, c['POTENTIAL']],
                   E=d[:, c['TOTAL']], T=d[:, c['TEMP']])

def analyze_openmm():
    t, res = read_openmm('../openmm/out/nve.csv')

    print(f'Average temperature = {res['T'].mean():.2f} K')
    print(f'Average potential energy = {res['PE'].mean():.2f} kcal/mol')

    plt.figure(1)
    plt.title('Energy')
    plt.xlabel('t (ps)')
    plt.ylabel('energy (kcal/mol)')
    plt.axvline(x=2, color='blue', linestyle='--', linewidth=1.5)
    plt.plot(t, res['PE'], label='PE')
    plt.plot(t, res['KE'], label='KE')
    plt.plot(t, res['E' ], label='Total')
    plt.legend()
    plt.savefig('openmm_energy.png')

    plt.figure(2)
    plt.xlabel('t (ps)')
    plt.ylabel('energy (kcal/mol)')
    plt.title('Total Energy Fluctuation')
    plt.axvline(x=2, color='blue', linestyle='--', linewidth=1.5)
    plt.plot(t, res['E'] - res['E'][0])
    plt.savefig('openmm_fluctuation.png')

    plt.figure(3)
    plt.xlabel('t (ps)')
    plt.ylabel('T (K)')
    plt.title('Temperature')
    plt.axvline(x=2, color='blue', linestyle='--', linewidth=1.5)
    plt.plot(t, res['T'])
    plt.savefig('openmm_temp.png')

def analyze_namd():
    t, res = read_namd('../namd/out/nve.log')

    print(f'Average temperature = {res['T'].mean():.2f} K')
    print(f'Average potential energy = {res['PE'].mean():.2f} kcal/mol')

    plt.figure(4)
    plt.title('Energy')
    plt.xlabel('t (ps)')
    plt.ylabel('energy (kcal/mol)')
    plt.axvline(x=2, color='blue', linestyle='--', linewidth=1.5)
    plt.plot(t, res['PE'], label='PE')
    plt.plot(t, res['KE'], label='KE')
    plt.plot(t, res['E' ], label='Total')
    plt.legend()
    plt.savefig('namd_energy.png')

    plt.figure(5)
    plt.xlabel('t (ps)')
    plt.ylabel('energy (kcal/mol)')
    plt.title('Total Energy Fluctuation')
    plt.axvline(x=2, color='blue', linestyle='--', linewidth=1.5)
    plt.plot(t, res['E'] - res['E'][0])
    plt.savefig('namd_fluctuation.png')

    plt.figure(6)
    plt.xlabel('t (ps)')
    plt.ylabel('T (K)')
    plt.title('Temperature')
    plt.axvline(x=2, color='blue', linestyle='--', linewidth=1.5)
    plt.plot(t, res['T'])
    plt.savefig('namd_temp.png')

if __name__ == '__main__':
    analyze_namd()
    analyze_openmm()
    plt.show()