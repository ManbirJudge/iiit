import os

os.environ['OPENMM_CPU_THREADS'] = '12'

import openmm as mm
from openmm import app, unit

# TODO: 

# ---
params = app.AmberPrmtopFile('../input/2HEP.prmtop')
coords = app.AmberInpcrdFile('../input/2HEP_equil.rst7')

# ---
system = params.createSystem(
    nonbondedMethod=app.CutoffPeriodic,
    nonbondedCutoff=0.9 * unit.nanometer,
    rigidWater=False,
    removeCMMotion=True
)

for force in system.getForces():
    if isinstance(force, mm.NonbondedForce):
        nb = force
        nb.setUseDispersionCorrection(False)  # LJ correction off

# integrator
integrator = mm.VerletIntegrator(0.001 * unit.picoseconds)

# ---
platform = mm.Platform.getPlatformByName('CPU')
platform.setPropertyDefaultValue('Threads', '12') 

sim = app.Simulation(params.topology, system, integrator, platform)
sim.context.setPositions(coords.positions)
sim.context.setPeriodicBoxVectors(*coords.boxVectors)

# initial velocities according to 300 K
sim.context.setVelocitiesToTemperature(300 * unit.kelvin, 12345)

# output
sim.reporters.append(app.StateDataReporter('out/nve.csv', 50, step=True, time=True, potentialEnergy=True, kineticEnergy=True, totalEnergy=True, temperature=True))
sim.reporters.append(app.DCDReporter('out/nve.dcd', 50))

# run
n_steps = 12000
sim.step(n_steps)
